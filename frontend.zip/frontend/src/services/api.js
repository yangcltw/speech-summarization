import axios from "axios";
   
   export const uploadAudio = async (file) => {
       const formData = new FormData();
       formData.append("file", file);
       const response = await axios.post("http://localhost:8000/upload", formData);
       return response.data;
   };