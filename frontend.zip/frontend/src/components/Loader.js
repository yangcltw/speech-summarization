// Loader.js
const Loader = () => <div>Loading...</div>;
export default Loader;