// Navbar.js
   const Navbar = () => (
           <nav>
               <h1>Speech Summarization</h1>
           </nav>
       );
       export default Navbar;